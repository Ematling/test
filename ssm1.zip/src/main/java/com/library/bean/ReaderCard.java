package com.library.bean;

import java.io.Serializable;

import org.springframework.stereotype.Component;
@Component
public class ReaderCard implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long reader_id;
    private String username;
    private String password;
	public long getReader_id() {
		return reader_id;
	}
	public void setReader_id(long reader_id) {
		this.reader_id = reader_id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

   
}
