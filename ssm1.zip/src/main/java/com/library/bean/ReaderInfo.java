package com.library.bean;

import java.io.Serializable;
import java.util.Date;

import org.springframework.stereotype.Component;
@Component
public class ReaderInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long reader_id;
	private String name;
	private String sex;
	private Date birth;
	private String address;
	private String phone;

	public long getReader_id() {
		return reader_id;
	}

	public void setReader_id(long reader_id) {
		this.reader_id = reader_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Date getBirth() {
		return birth;
	}

	public void setBirth(Date birth) {
		this.birth = birth;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}
